// startup.cpp

// stub module: launches assembly language program

extern "C" void asm_main();		// asm startup proc

void main()
{
	asm_main();
}

