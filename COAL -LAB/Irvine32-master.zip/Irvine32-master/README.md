# Irvine32
A library for assembly language.
This repo gives you a convenient and powerful library that you can use to simplify
tasks related to input-output and string handling in assembly language programming.

Credits:

Assembly Language for x86 Processors, Sixth Edition.

by

KIP R. IRVINE
Florida International University
School of Computing and Information Sciences
